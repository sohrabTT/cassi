"""Stub for the optional PyTorch backend.

This file documents how to plug a real LLM into CASSI. The implementation is
intentionally not loaded at import time so that CASSI stays dependency-free
by default. Install the optional extra ``pip install cassi-spec[torch]`` to
enable it.
"""

from __future__ import annotations

from typing import Any

from cassi.backends.base import BaseBackend, DraftProposal, TargetScores
from cassi.utils import logger


class TorchBackend(BaseBackend):
    """Skeleton PyTorch backend.

    Designed to wrap any HuggingFace causal LM as the *target* model and a
    smaller LM as the *draft* model. Implementers must fill in:

    - ``setup``: load tokenizer, models, configure device, prime KV cache.
    - ``draft_next``: run a single forward pass of the draft model on the
      cached prefix and return ``argmax`` (or sampled) token + logprob.
    - ``target_score``: run a single batched forward pass of the target
      model with ``context_ids + candidate_ids`` and return the target's
      argmax and logprob at the *candidate positions*.

    The engine only needs the abstract contract; you are free to use
    ``torch.compile``, flash attention, paged KV cache, quantization, or
    any other optimisation under the hood.
    """

    name = "torch"

    def __init__(
        self,
        target_model_name: str,
        draft_model_name: str,
        device: str = "cuda",
        dtype: str = "float16",
    ) -> None:
        try:
            import torch  # noqa: F401
            import transformers  # noqa: F401
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "TorchBackend requires the 'torch' extra. "
                "Install with: pip install cassi-spec[torch]"
            ) from e

        self.target_model_name = target_model_name
        self.draft_model_name = draft_model_name
        self.device = device
        self.dtype = dtype
        self._target: Any = None
        self._draft: Any = None
        self._tokenizer: Any = None
        logger.info("TorchBackend initialised (target=%s, draft=%s)",
                    target_model_name, draft_model_name)

    def setup(self, prompt: str) -> None:
        raise NotImplementedError(
            "Implement: load tokenizer, load target & draft models to device, "
            "tokenize prompt, prime KV caches."
        )

    def draft_next(self, context_ids: list[int]) -> DraftProposal:
        raise NotImplementedError(
            "Implement: single forward pass of draft model over the cached "
            "prefix; return argmax token and its logprob."
        )

    def target_score(
        self, context_ids: list[int], candidate_ids: list[int]
    ) -> TargetScores:
        raise NotImplementedError(
            "Implement: single batched forward pass of the target model over "
            "context_ids + candidate_ids; return the target's argmax + "
            "logprob at each candidate position."
        )

    def encode(self, text: str) -> list[int]:
        raise NotImplementedError("Use the tokenizer's __call__ here.")

    def decode(self, ids: list[int]) -> str:
        raise NotImplementedError("Use the tokenizer's decode here.")


__all__ = ["TorchBackend"]
