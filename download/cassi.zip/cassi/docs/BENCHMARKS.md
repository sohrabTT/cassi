# CASSI Benchmarks

This document captures the canonical benchmark numbers for CASSI. All
results are produced on the `ToyBackend` with a fixed seed (`seed=42`),
64 tokens generated, and the default adaptive-k controller
(`k_min=2, k_max=8, k_init=4`).

## Speedup vs draft-model accuracy

Run with:

```bash
python benchmarks/speedup.py
```

| draft acc | tokens | passes | accept% | speedup | final k |
|-----------|--------|--------|---------|---------|---------|
| 0.20      | 64     | 52     | 12.3%   | 1.23×   | 2       |
| 0.40      | 64     | 43     | 25.0%   | 1.49×   | 2       |
| 0.60      | 64     | 33     | 47.1%   | 1.94×   | 2       |
| 0.70      | 64     | 29     | 51.4%   | 2.21×   | 2       |
| 0.80      | 64     | 21     | 43.7%   | 3.05×   | 7       |
| 0.90      | 64     | 12     | 61.4%   | 5.33×   | 8       |
| 1.00      | 64     | 8      | 100.0%  | 8.00×   | 8       |

### Observations

- At `draft_acc = 1.0` (perfect draft), speedup converges to `k_max = 8`.
  The engine issues 8 forward passes to emit 64 tokens — exactly `64 / 8`.
- At `draft_acc = 0.2` (bad draft), speedup drops to `1.23×`. The adaptive-k
  controller throttles `k` to `k_min = 2` to avoid wasting compute.
- The transition around `draft_acc = 0.7 → 0.8` is where the controller
  *opens up* `k` from 2 to 7-8, which is visible in the `final_k` column.

## Throughput: pipelined vs sequential

Run with:

```bash
python benchmarks/throughput.py --num-prompts 8 --tokens 32
```

The default `ToyBackend` has `target_lag_ms = draft_lag_ms = 0`, so the
pipelined mode degenerates to sequential. To exercise the overlap, pass
non-zero lags:

```bash
python benchmarks/throughput.py --target-lag-ms 10 --draft-lag-ms 2
```

### Honest note on the current pipeline

The `CrossRequestPipeline` as currently shipped is a **scheduler pattern**,
not a true concurrent executor. It models the API contract (request
submission, ordered completion, request-id forwarding) but does not yet
issue draft work for queued requests concurrently with target verification
of the in-flight one. The reason is that the engine currently exposes a
synchronous `generate()` method; a true overlapping implementation would
require the draft and target methods to be async (or threaded) so the
scheduler can issue draft steps for request B during the target pass of
request A.

This is a deliberate scope decision: the goal of CASSI v0.1 is to provide
a faithful, testable implementation of the *algorithm* and the *API*,
without dragging in a specific concurrency runtime. Real-deployment
numbers will depend on the backend (PyTorch with CUDA streams, llama.cpp
with Vulkan queues, a remote API with HTTP/2 multiplexing, etc.).

Real-deployment numbers depend on the target model, the device, and the
request mix. CASSI's role is to provide a faithful *algorithmic* baseline
against which production backends can be compared.

## Reproducibility

All benchmarks use `seed=42` and the default adaptive-k controller. To
reproduce:

```bash
pip install -e ".[viz]"
python benchmarks/speedup.py
python benchmarks/throughput.py
```

Plots are saved to `results/benchmark_speedup.png` and
`results/throughput.png` by default.
